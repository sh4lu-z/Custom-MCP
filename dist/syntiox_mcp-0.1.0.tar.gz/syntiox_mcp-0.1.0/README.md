<div align="center">
  <h1>⚙️ Syntiox MCP Tools</h1>
  <p><b>Model Context Protocol (MCP) server collection for Cursor, Claude Desktop, and LM Studio on Windows.</b></p>
  
  [![MCP Badge](https://lobehub.com/badge/mcp/sh4lu-z-custom-mcp)](https://lobehub.com/mcp/sh4lu-z-custom-mcp)
  [![Python](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
</div>

<br/>

Syntiox MCP Tools provide extensive local PC control, Google Workspace integrations (Gmail, Sheets, Docs, Drive, Calendar, etc.), weather updates, news, and more directly into your favorite AI IDEs or desktop clients.

## 🚀 Features

- 🖥️ **System Control:** Brightness, volume, power actions, stats, and process management.
- 🌐 **Web Tools:** DuckDuckGo search, Weather, Sri Lanka News (Esena).
- ☁️ **Google Workspace:** Over 124 standalone tools across Gmail, Drive, Calendar, Docs, Sheets, Slides, Tasks, and Forms.
- 📋 **Utilities:** Clipboard manager, screenshot taker, file system explorer, and reminders.
- 🧠 **Master Router:** An optional AI-powered gateway to chain multiple services using natural language (requires LM Studio).

---

## 📦 Installation

We've made installation incredibly simple. You can install Syntiox MCP directly via `pip`.

### 1. Install via pip

Open your terminal and run:

```bash
pip install syntiox-mcp
```
*(If you are installing from source: clone the repo, navigate to the folder, and run `pip install .`)*

### 2. Google OAuth (Required for Google Workspace tools)

To use Google integrations (Gmail, Calendar, Drive, etc.), you need to set up OAuth:

```bash
# Copy the template to create your credentials file
copy credentials.json.example credentials.json

# Run the auth setup script to generate your token.json
python google/auth_setup.py
```
*Note: You need to download your `credentials.json` from the [Google Cloud Console](https://console.cloud.google.com/). See [Google Cloud Setup](#-google-cloud-setup) below for details.*

---

## 🔌 How to connect to Cursor / Claude

With the `syntiox-mcp` package installed, you can use the unified `syntiox-mcp` CLI command to start any server. You no longer need to point to specific `.py` script paths!

### Option A — Separate Handlers (Recommended for Cursor)

Register only the services you want. The AI agent will see the real tool names directly (e.g., `update_single_cell`, `send_gmail_email`).

**In Cursor:** Edit your MCP config (e.g., `.cursor/mcp.json` or via Settings → MCP):

```json
{
  "mcpServers": {
    "google-gmail": {
      "command": "syntiox-mcp",
      "args": ["gmail"]
    },
    "google-sheets": {
      "command": "syntiox-mcp",
      "args": ["sheets"]
    },
    "syntiox-system": {
      "command": "syntiox-mcp",
      "args": ["system"]
    },
    "syntiox-web-search": {
      "command": "syntiox-mcp",
      "args": ["search"]
    }
  }
}
```

**Available Server Names:**
- **System:** `system`, `clipboard`, `file`, `reminder`, `screenshot`
- **Web:** `search`, `sri-news`, `weather`
- **Google:** `gmail`, `calendar`, `drive`, `docs`, `sheets`, `slides`, `tasks`, `forms`, `google-news`
- **Advanced:** `master-router`, `python-sandbox`

**In Claude Desktop:** Add the same JSON snippet under `%APPDATA%\Claude\claude_desktop_config.json` inside the `mcpServers` block.

### Option B — Master Router

One single server to rule them all. The Master Router uses an LLM planner to break down natural language requests into multi-step tool calls.

```json
{
  "mcpServers": {
    "syntiox-router": {
      "command": "syntiox-mcp",
      "args": ["master-router"]
    }
  }
}
```

*Requirements for Master Router:*
- LM Studio running locally with API at `http://localhost:1234/v1/chat/completions`.
- Natural language flow (e.g. *"Check the weather in Colombo and send it to my email"*).

---

## ☁️ Google Cloud Setup

To get your `credentials.json` for Google services:
1. Go to [Google Cloud Console](https://console.cloud.google.com/) and create a project.
2. Enable the APIs you need: Gmail, Calendar, Drive, Docs, Sheets, Slides, Tasks, Forms.
3. Create an **OAuth 2.0 Desktop client**.
4. Download the JSON and save it as `credentials.json` in your project folder.
5. Run `python google/auth_setup.py` and sign in through your browser.

---

## 🛡️ Security & Privacy

**Never push the following files to a public repository:**
- `credentials.json` (Google OAuth client secret)
- `google/token.json` (Your Google access + refresh tokens)
- `.env` (API keys)
- `reminders.json` (Local personal reminders)

These are already listed in the `.gitignore`. Use `credentials.json.example` as a template only.
If you accidentally commit secrets, revoke them immediately from the Google Cloud Console.

## 📝 Notes

- Built primarily for **Windows** (brightness, volume, notifications).
- Each Google handler is **independent** — MCP config decides what the agent can use.
- Large tool counts (~124+ Google tools) may be heavy for small local models; prefer registering only the services you need.

---
<div align="center">
  <i>Developed with ❤️ for the AI community.</i>
</div>
